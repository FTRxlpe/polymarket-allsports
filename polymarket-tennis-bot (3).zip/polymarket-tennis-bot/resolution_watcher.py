"""
Periodically checks whether open positions' markets have resolved, and if so
computes P&L and reports it to the RiskManager (updates bankroll, win-streak
tracking, and the loss-streak pause).

Run this as a second process alongside main.py:
    python resolution_watcher.py
"""
import logging
import os
import time

import requests
from dotenv import load_dotenv

load_dotenv()

import config
from risk_manager import RiskManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("resolution_watcher")

CHECK_INTERVAL_SECONDS = 60


def fetch_market_status(slug: str) -> dict:
    """Look up a market's resolution status via the public Gamma API."""
    url = "https://gamma-api.polymarket.com/markets"
    resp = requests.get(url, params={"slug": slug}, timeout=10)
    resp.raise_for_status()
    results = resp.json()
    return results[0] if results else {}


def run():
    risk = RiskManager()
    logger.info("Resolution watcher started")

    while True:
        for slug in list(risk.state.open_positions):
            try:
                market = fetch_market_status(slug)
                if not market.get("closed"):
                    continue

                # NOTE: You'll need to reconcile this against your own trade
                # log (logs/paper_trades.jsonl or your live fill records) to
                # know which outcome you held and at what price/size, in
                # order to compute exact pnl. This is a simplified skeleton —
                # tighten it to your own record format before relying on it.
                winning_outcome = market.get("winningOutcome") or market.get("outcome")
                logger.info(f"Market resolved: {slug} -> winner: {winning_outcome}")

                # Placeholder result — replace `won`/`pnl` with values computed
                # from your actual position record for this market.
                won = True
                pnl = 0.0
                risk.record_result(slug, won=won, pnl=pnl)

            except Exception:
                logger.exception(f"Error checking resolution for {slug}")

        time.sleep(CHECK_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
