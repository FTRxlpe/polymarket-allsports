"""
Determines which market slugs currently belong to a given sport (e.g. nba,
tennis), using Polymarket's official tag system via the Gamma API.

IMPORTANT: the Gamma /events endpoint filters by *numeric* `tag_id`, not by
a tag slug string. An earlier version of this file passed `tag=<slug>` as
the query param, which Gamma silently ignored — it returned the same
generic "top active events" list regardless of the value, which meant the
sport filter wasn't actually filtering anything. This version resolves the
tag slug to its numeric ID first (via GET /tags?slug=...), then filters
events with that ID (GET /events?tag_id=...), which is the officially
documented approach.
"""
import logging
import time
from typing import Optional, Set

import requests

import config

logger = logging.getLogger("sport_filter")

GAMMA_API = "https://gamma-api.polymarket.com"

# Version marker so it's obvious in the logs which version of this file is
# actually running — avoids confusion after multiple zip re-uploads.
_MODULE_VERSION = "sport_filter.py v3 (tag_id resolution + 429 backoff)"
logger.info(f"Loaded {_MODULE_VERSION}")


class SportFilter:
    def __init__(self, tag_slug: str = None, refresh_interval_seconds: int = 300):
        self.tag_slug = tag_slug or config.SPORT_TAG_SLUG
        self.refresh_interval = refresh_interval_seconds
        self._slugs: Set[str] = set()
        self._last_refresh = 0.0
        self._tag_id: Optional[int] = None
        self.session = requests.Session()

    def _resolve_tag_id(self) -> Optional[int]:
        """Look up the numeric tag_id for self.tag_slug. Cached for the life
        of this instance since a sport's tag_id doesn't change."""
        if self._tag_id is not None:
            return self._tag_id

        # Try direct slug lookup first.
        try:
            resp = self.session.get(
                f"{GAMMA_API}/tags", params={"slug": self.tag_slug}, timeout=15
            )
            resp.raise_for_status()
            results = resp.json()
            if results:
                entry = results[0] if isinstance(results, list) else results
                if entry.get("id"):
                    self._tag_id = int(entry["id"])
                    logger.info(f"Resolved tag '{self.tag_slug}' -> tag_id={self._tag_id}")
                    return self._tag_id
        except (requests.RequestException, ValueError, KeyError) as e:
            logger.warning(f"Direct tag slug lookup failed for '{self.tag_slug}': {e}")

        # Fallback: paginate through /tags and match slug or label
        # case-insensitively (some sport tags may not resolve via ?slug=).
        offset = 0
        page_size = 100
        for _ in range(10):  # up to 1000 tags scanned, generous ceiling
            try:
                resp = self.session.get(
                    f"{GAMMA_API}/tags",
                    params={"limit": page_size, "offset": offset},
                    timeout=15,
                )
                resp.raise_for_status()
                page = resp.json()
            except requests.RequestException as e:
                logger.warning(f"Tag listing failed at offset {offset}: {e}")
                break

            if not page:
                break

            for tag in page:
                slug = (tag.get("slug") or "").lower()
                label = (tag.get("label") or "").lower()
                if slug == self.tag_slug.lower() or label == self.tag_slug.lower():
                    self._tag_id = int(tag["id"])
                    logger.info(
                        f"Resolved tag '{self.tag_slug}' -> tag_id={self._tag_id} "
                        f"(via full tag list scan, label='{tag.get('label')}')"
                    )
                    return self._tag_id

            offset += page_size

        logger.error(
            f"Could not resolve a tag_id for '{self.tag_slug}' — the sport "
            f"filter will not match any markets until this is fixed. Check "
            f"the exact tag slug/label via https://gamma-api.polymarket.com/tags"
        )
        return None

    def _refresh(self):
        # Mark refreshed now, even before we know if it'll succeed, so a
        # failed attempt doesn't get retried on every single is_match() call
        # in the hot path — it'll wait out the normal refresh_interval like
        # a successful refresh would, instead of hammering the API.
        self._last_refresh = time.time()

        tag_id = self._resolve_tag_id()
        if tag_id is None:
            return

        all_slugs = set()
        offset = 0
        page_size = 100
        for _ in range(20):
            page_events = self._fetch_events_page(tag_id, offset, page_size)
            if page_events is None:
                break  # gave up after retries — keep whatever we gathered so far
            if not page_events:
                break  # no more pages

            for event in page_events:
                for market in event.get("markets", []):
                    slug = market.get("slug")
                    if slug:
                        all_slugs.add(slug)

            if len(page_events) < page_size:
                break
            offset += page_size

        if all_slugs:
            self._slugs = all_slugs
            logger.info(
                f"Refreshed '{self.tag_slug}' (tag_id={tag_id}) market list: "
                f"{len(all_slugs)} active slugs"
            )
        else:
            logger.warning(
                f"Gamma API returned 0 active '{self.tag_slug}' markets "
                f"(tag_id={tag_id}) — keeping previous list "
                f"({len(self._slugs)} slugs). Will retry at the next "
                f"refresh interval ({self.refresh_interval}s) rather than immediately."
            )

    def _fetch_events_page(self, tag_id: int, offset: int, page_size: int):
        """One page of /events, with retry-with-backoff on 429. Returns None
        if it gives up after retries (caller should stop paginating)."""
        delay = 2.0
        for attempt in range(4):
            try:
                resp = self.session.get(
                    f"{GAMMA_API}/events",
                    params={
                        "tag_id": tag_id,
                        "active": "true",
                        "closed": "false",
                        "limit": page_size,
                        "offset": offset,
                    },
                    timeout=15,
                )
                if resp.status_code == 429:
                    logger.warning(
                        f"Rate limited (429) fetching events page (offset={offset}), "
                        f"retrying in {delay:.1f}s (attempt {attempt + 1}/4)"
                    )
                    time.sleep(delay)
                    delay *= 2
                    continue
                resp.raise_for_status()
                return resp.json()
            except requests.RequestException as e:
                logger.warning(f"Failed to fetch events page (offset={offset}): {e}")
                return None
        logger.warning(f"Giving up on events page (offset={offset}) after repeated 429s")
        return None

    def is_match(self, slug: str) -> bool:
        if time.time() - self._last_refresh > self.refresh_interval:
            self._refresh()
        return slug in self._slugs
